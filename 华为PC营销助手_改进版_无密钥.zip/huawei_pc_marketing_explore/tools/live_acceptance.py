"""有限真实验收：一次产品、一个平台，不创建笔记，不保存完整共享资料。

运行需显式加 --live，会消耗模型费用和 ima 读取额度。遇到接口错误立即停止，
不自动换库、不绕过限额。报告只记状态、数量和错误，不记密钥、内部 ID 或原文。
"""

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from checks import EvidenceError
from config import ROOT, load_settings
from evidence_utils import timestamp
from ima_client import ImaClient, ImaError
from llm import LangChainEngine, ModelError
from schemas import PLATFORM_RULES, Task
from workflow import run_workflow


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live", action="store_true", help="确认执行真实读取与有费用的模型请求")
    parser.add_argument("--category", default="01-鸿蒙电脑")
    parser.add_argument("--product", default="HUAWEI MateBook 14")
    parser.add_argument("--platform", choices=list(PLATFORM_RULES), default="朋友圈")
    args = parser.parse_args()
    if not args.live:
        print("未联网。真实验收请加 --live；它会消耗接口额度。")
        return 0

    settings = load_settings()
    report = ["# 本轮有限真实验收", "", f"- 时间：{timestamp()}",
              f"- 配置知识库：{settings.kb_name}", f"- 模型：{settings.model}",
              f"- 任务：大学新生 / 上课携带并整理课业 / {args.platform}",
              "- 范围：一个产品、一个平台；不写个人笔记，不修改共享知识库。"]
    outcome = 1
    try:
        client = ImaClient(settings)
        client.connect()
        current = client.product_root()
        # 精确匹配目录名称，不在出错时偷偷换一个相近型号。
        for name in (args.category, args.product):
            folders = [item for item in client.list_folder(client.entry_id(current))
                       if client.is_folder(item) and item.get("title") == name]
            if len(folders) != 1:
                raise ImaError(f"无法唯一找到目录“{name}”，请在网页核对真实目录名称。")
            current = folders[0]
        print("知识库与产品目录读取成功；正在加载原文与图片。", flush=True)
        evidence = client.load_product(current)
        report += [f"- 产品：{evidence.product_model}", f"- 资料数量：{len(evidence.sources)}",
                   f"- 可用图片：{sum(image.verified for image in evidence.images)} / {len(evidence.images)}"]
        task = Task(product_model=evidence.product_model, audience="大学新生",
                    scenario="上课携带并整理课业", platform=args.platform)
        engine = LangChainEngine(settings)
        result = run_workflow(task, evidence, engine, progress=lambda message: print(message, flush=True),
                              evidence_loader=client.retrieve_for_task)
        report += [f"- 完整流程：已返回结果；检查通过：{'是' if result.review.passed else '否'}",
                   f"- 模型请求次数：{engine.request_count}", f"- 取证重试：{result.extraction_retry_count}",
                   f"- 文案改写：{result.repair_count}", f"- 事实审核行：{len(result.review.fact_checks)}",
                   f"- 图片审核行：{len(result.review.image_checks)}",
                   f"- 合规审核类别：{len({row.category for row in result.review.compliance_checks})}"]
        report += [f"- 稿件问题：{issue.message}" for issue in result.review.issues]
        report += [f"- 阻塞项：{item}" for item in result.review.blocking]
        outcome = 0 if result.review.passed else 2
    except (ImaError, ModelError, EvidenceError) as error:
        report += [f"- 未完成：{error}", "- 已停止依赖步骤，没有重试绕过或更改知识库。"]
        print(f"本次未完成：{error}", flush=True)
    report += ["", "此记录不代表三平台全覆盖、模型质量零漏检或全部参赛条件已满足。", ""]
    # 留存每一次验收，避免后来的成功覆盖之前发现的问题。
    history = ROOT / "outputs"
    history.mkdir(exist_ok=True)
    history_name = "真实验收_" + timestamp().replace(":", "").replace("+", "_") + ".md"
    (history / history_name).write_text("\n".join(report), encoding="utf-8")
    path = ROOT / "真实验收记录_本轮.md"
    path.write_text("\n".join(report), encoding="utf-8")
    print(f"状态记录已保存：{path}", flush=True)
    return outcome


if __name__ == "__main__":
    raise SystemExit(main())
