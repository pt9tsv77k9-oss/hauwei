"""Node 查找测试：只替换环境和文件检查，不安装软件，也不启动外部进程。"""

from pathlib import Path

from node_runtime import find_node


def test_node_from_path_takes_priority(monkeypatch):
    """用户 PATH 已配置 Node 时，优先采用它，不擅自切换到其他安装版本。"""
    monkeypatch.setattr("node_runtime.shutil.which", lambda _: "configured-node")
    assert find_node() == "configured-node"


def test_user_install_is_found_without_refreshed_path(monkeypatch):
    """模拟旧窗口找不到 Node，但用户目录已有安装的情形。"""
    monkeypatch.setattr("node_runtime.shutil.which", lambda _: None)
    base = Path("demo-user-local").resolve()
    expected = base / "Programs/nodejs/node.exe"
    monkeypatch.setenv("LOCALAPPDATA", str(base))
    # 不真正创建 node.exe，只让路径检查对预期位置返回 True。
    monkeypatch.setattr(Path, "is_file", lambda path: path == expected)
    assert find_node() == str(expected)


def test_missing_node_returns_none(monkeypatch):
    """PATH 和所有候选位置都没有 Node 时，返回 None 供页面显示安装提示。"""
    monkeypatch.setattr("node_runtime.shutil.which", lambda _: None)
    monkeypatch.setattr(Path, "is_file", lambda _: False)
    assert find_node() is None
